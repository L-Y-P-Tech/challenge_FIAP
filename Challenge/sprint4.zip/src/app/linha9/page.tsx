"use client";
import LinhaMetro from "../componentes/LinhaMetro";

export default function Linha9() {
  return <LinhaMetro linhaId="linha9" />;
}