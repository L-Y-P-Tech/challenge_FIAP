"use client";
import LinhaMetro from "../componentes/LinhaMetro";

export default function Linha15() {
  return <LinhaMetro linhaId="linha15" />;
}