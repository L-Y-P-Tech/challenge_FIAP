"use client";
import LinhaMetro from "../componentes/LinhaMetro";

export default function Linha12() {
  return <LinhaMetro linhaId="linha12" />;
}