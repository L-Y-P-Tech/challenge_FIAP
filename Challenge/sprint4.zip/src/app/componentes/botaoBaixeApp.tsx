"use client";
export default function BotaoBaixeApp() {
    return (
      <a href="#" className="bg-[#8B2119] text-white text-center py-3 w-full    cursor-pointer block rounded-lg transition-all duration-200 hover:shadow-lg hover:transform hover:-translate-y-1">
      📲 Baixe o aplicativo da ViaMobilidade  
      </a>
    );
  }
  