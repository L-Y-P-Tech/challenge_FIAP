
export default function BotaoFaleConosco() {
  return (
    <a href="https://rodovias.grupoccr.com.br/riosp/central-de-ajuda/fale-conosco/" className="bg-gray-100 p-4 rounded-lg shadow-md text-center flex flex-col items-center">
        Fale Conosco
    </a>
  );
}
