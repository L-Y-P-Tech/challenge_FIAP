"use client";
import LinhaMetro from "../componentes/LinhaMetro";

export default function Linha13() {
  return <LinhaMetro linhaId="linha13" />;
}