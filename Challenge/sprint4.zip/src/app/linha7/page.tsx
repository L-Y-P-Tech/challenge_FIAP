"use client";
import LinhaMetro from "../componentes/LinhaMetro";

export default function Linha7() {
  return <LinhaMetro linhaId="linha7" />;
}