"use client";
import LinhaMetro from "../componentes/LinhaMetro";

export default function Linha8() {
  return <LinhaMetro linhaId="linha8" />;
}