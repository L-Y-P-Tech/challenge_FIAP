"use client";
import LinhaMetro from "../componentes/LinhaMetro";

export default function Linha5() {
  return <LinhaMetro linhaId="linha5" />;
}