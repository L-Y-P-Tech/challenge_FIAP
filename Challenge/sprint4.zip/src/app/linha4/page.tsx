"use client";
import LinhaMetro from "../componentes/LinhaMetro";

export default function Linha4() {
  return <LinhaMetro linhaId="linha4" />;
}