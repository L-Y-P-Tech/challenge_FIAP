"use client";
import LinhaMetro from "../componentes/LinhaMetro";

export default function Linha3() {
  return <LinhaMetro linhaId="linha3" />;
}