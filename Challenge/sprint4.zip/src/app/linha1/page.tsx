"use client";
import LinhaMetro from "../componentes/LinhaMetro";

export default function Linha1() {
  return <LinhaMetro linhaId="linha1" />;
}