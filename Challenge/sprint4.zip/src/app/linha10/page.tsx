"use client";
import LinhaMetro from "../componentes/LinhaMetro";

export default function Linha10() {
  return <LinhaMetro linhaId="linha10" />;
}