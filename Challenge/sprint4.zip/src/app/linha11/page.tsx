"use client";
import LinhaMetro from "../componentes/LinhaMetro";

export default function Linha11() {
  return <LinhaMetro linhaId="linha11" />;
}